# SoftwareWebApp
Software Engineering project 2018, Sean Mc Cann, Michael Gavin, Patryk Kozak, Aaron Forde, John Cummins.
Web App to search for available internships.
