var mongoose = require('mongoose');
var connection = mongoose.connect('mongodb://mongodb3578ms:ze6hoq@danu7.it.nuigalway.ie:8717/mongodb3578');

exports.connection = connection;
